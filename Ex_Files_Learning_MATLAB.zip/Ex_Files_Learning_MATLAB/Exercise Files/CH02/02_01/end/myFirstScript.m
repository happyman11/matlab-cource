
%My first script, I'm so excited
disp('Go go gadget script!')

myMat = randi(3,3);
myMatTranspose = myMat';