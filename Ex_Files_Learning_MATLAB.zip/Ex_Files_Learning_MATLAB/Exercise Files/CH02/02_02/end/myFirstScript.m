
%Create some standard matrices
myZeros = zeros(20,30);
myOnes = ones(100,100);
myRandomInts = randi(5,6);


%My first script, I'm so excited
% disp('Go go gadget script!')
% 
% myMat = randi(3,3);
% myMatTranspose = myMat';