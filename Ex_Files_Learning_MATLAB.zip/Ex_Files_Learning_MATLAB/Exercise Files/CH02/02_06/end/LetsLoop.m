%for loop
n = 25;
step = 5;

for i = 0:step:n
    disp(i)
end