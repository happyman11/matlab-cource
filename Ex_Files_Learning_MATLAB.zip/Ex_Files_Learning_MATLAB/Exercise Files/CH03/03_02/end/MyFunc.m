function [c] = MyFunc(a,b)
%MYFUNC Caluclate c from pythagoras
%   I love right triangles
c = sqrt((a^2) + (b^2));
end

