myIm = imread('cake.jpg');

figure(2)
image(myIm)

figure(3)
imshow(myIm)